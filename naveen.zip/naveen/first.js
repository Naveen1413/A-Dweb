for (let count = 1; count <= 100; count++){
    console.log("naveen chaudhary");
    
}